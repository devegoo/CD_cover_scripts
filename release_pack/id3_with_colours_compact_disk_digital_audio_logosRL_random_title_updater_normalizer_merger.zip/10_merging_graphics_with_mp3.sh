#!/bin/bash
echo THIS NEEDS RUBY GEM fancy_audio install tip  cmd: pip install fancy_audio
cd ghostcopy/
fancy_audio
echo "Merging Covers Done"
