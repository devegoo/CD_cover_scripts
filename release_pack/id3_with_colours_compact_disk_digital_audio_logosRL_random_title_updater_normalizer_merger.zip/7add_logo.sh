#!/bin/sh
mkdir ghostcopy/logo
cp bullLeft.png bullRight.png ghostcopy/logo/
for dir in ghostcopy
do
    (
      for i in ghostcopy/*.mp3.png
      do
convert "$i" ghostcopy/logo/bullLeft.png -geometry +150+500 -composite "$i"
convert "$i" ghostcopy/logo/bullRight.png -geometry +750+500 -composite "$i"
done
    )
done
