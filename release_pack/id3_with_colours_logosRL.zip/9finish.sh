 
#!/bin/bash
for f in ghostcopy/*.mp3.png; do
    mv -- "$f" "${f%.mp3.png}.png"
done
