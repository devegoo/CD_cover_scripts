#!/bin/sh
    for i in ghostcopy/*.mp3
do
    r=$(( $RANDOM % 255 ));
    g=$(( $RANDOM % 255 ));
    b=$(( $RANDOM % 255 ));
    maincolor="rgba($r,$g,$b,1)"
    backcolor="rgba($b,$g,$r,1)"
    band=$(mp3info -p %a "$i")
          convert "$i.png" -pointsize 82 -fill "$mainColor" \
           -stroke "$backcolor" -strokewidth 25 -annotate +400+200 "$band" \
           -stroke "$mainColor" -strokewidth 20 -annotate +400+200 "$band" \
           -stroke "$backcolor" -strokewidth 15 -annotate +400+200 "$band" \
           -stroke "$mainColor" -strokewidth 10 -annotate +400+200 "$band" \
           -stroke "$backcolor" -strokewidth  5 -annotate +400+200 "$band" \
           -stroke none                         -annotate +400+200 "$band" \
           "$i.png"
    album=$(mp3info -p %l "$i")
          convert "$i.png" -pointsize 48 -fill  "$mainColor" \
           -stroke "$backcolor"  -strokewidth 25 -annotate +300+700 "$album" \
           -stroke "$mainColor" -strokewidth 20 -annotate +300+700 "$album" \
           -stroke "$backcolor"  -strokewidth 15 -annotate +300+700 "$album" \
           -stroke "$mainColor" -strokewidth 10 -annotate +300+700 "$album" \
           -stroke "$backcolor"  -strokewidth  5 -annotate +300+700 "$album" \
           -stroke none                  -annotate +300+700 "$album" \
           "$i.png"
    track=$(mp3info -p %t "$i")
          convert "$i.png" -pointsize 48 -fill  "$backcolor" -annotate +300+800 "$track" "$i.png"
      done
