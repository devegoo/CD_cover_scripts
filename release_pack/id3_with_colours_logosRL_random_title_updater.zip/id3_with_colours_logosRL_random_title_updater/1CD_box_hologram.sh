#!/bin/sh
for dir in ghostcopy
do
    (
      for i in ghostcopy/*.png
      do
          convert -size 1000x1000 xc: -channel G +noise Random -virtual-pixel White -blur 0x7 -threshold 50% -separate +channel "$i"
      done
    )
done

